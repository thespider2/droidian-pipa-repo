#!/bin/sh
# pipa USB gadget setup — stock mtp-configfs cannot bind on this device
# (Android uses configs/b.1; stock rm/mkdir c.1 without UDC clear → -22).
set -e

MODE="${1:-none}"
GADGET=/sys/kernel/config/usb_gadget/g1
UDC=$(cat /sys/class/udc/* 2>/dev/null | head -1 || echo "")

# Find UDC from kernel cmdline if not found
if [ -z "$UDC" ]; then
    UDC=$(sed -n 's/.*androidboot\.usbcontroller=\([^ ]*\).*/\1/p' /proc/cmdline)
fi

if [ -z "$UDC" ]; then
    echo "No UDC found"
    exit 1
fi

# Tear down any existing gadget config (must unbind UDC first — Android
# leaves configs/b.1; stock mtp-configfs skips this and fails bind).
if [ -d "$GADGET" ]; then
    # #region agent log
    echo "DBG54b041 U-T usb-gadget teardown begin mode=$MODE udc=$(cat "$GADGET/UDC" 2>/dev/null || true) configs=$(ls "$GADGET/configs" 2>/dev/null | tr '\n' ',')" > /dev/kmsg
    # #endregion
    echo "" > "$GADGET/UDC" 2>/dev/null || true
    # #region agent log
    echo "DBG54b041 U-T usb-gadget UDC cleared mode=$MODE" > /dev/kmsg
    # #endregion
    sleep 0.1
    # Drop os_desc config symlinks if present
    for f in "$GADGET"/os_desc/*; do
        [ -L "$f" ] && rm -f "$f" 2>/dev/null || true
    done
    for c in "$GADGET"/configs/*/; do
        [ -d "$c" ] || continue
        for f in "$c"/*; do
            [ -L "$f" ] && rm -f "$f" 2>/dev/null || true
        done
        for s in "$c"/strings/*/; do
            [ -d "$s" ] && rmdir "$s" 2>/dev/null || true
        done
        rmdir "$c/strings" 2>/dev/null || true
        rmdir "$c" 2>/dev/null || true
    done
    # Android pre-creates many functions; only remove empty dirs we own.
    for f in "$GADGET"/functions/rndis.gs0 "$GADGET"/functions/mtp.gs0; do
        [ -d "$f" ] && rmdir "$f" 2>/dev/null || true
    done
    for s in "$GADGET"/strings/*/; do
        [ -d "$s" ] && rmdir "$s" 2>/dev/null || true
    done
    rmdir "$GADGET/strings" 2>/dev/null || true
fi

if [ "$MODE" = "none" ]; then
    rmdir "$GADGET" 2>/dev/null || true
    echo "USB gadget disabled"
    exit 0
fi

# Create gadget
mkdir -p "$GADGET"
mkdir -p "$GADGET/strings/0x409"
mkdir -p "$GADGET/configs/c.1"
mkdir -p "$GADGET/configs/c.1/strings/0x409"
mkdir -p "$GADGET/functions"

# Gadget strings
echo "Xiaomi" > "$GADGET/strings/0x409/manufacturer"
echo "Xiaomi Pad 6" > "$GADGET/strings/0x409/product"
echo "Droidian" > "$GADGET/strings/0x409/serialnumber"

# Gadget IDs
echo "0x18d1" > "$GADGET/idVendor"
echo "0x0001" > "$GADGET/bcdUSB"
echo "0x0223" > "$GADGET/bcdDevice"

# Configure
echo 500 > "$GADGET/configs/c.1/MaxPower"
echo 0xc0 > "$GADGET/configs/c.1/bmAttributes"

case "$MODE" in
    mtp)
        echo "0x4ee1" > "$GADGET/idProduct"
        mkdir -p "$GADGET/functions/mtp.gs0"
        echo "MTP" > "$GADGET/configs/c.1/strings/0x409/configuration"
        ln -sf "$GADGET/functions/mtp.gs0" "$GADGET/configs/c.1/f1"
        ;;
    rndis)
        echo "0x4ee2" > "$GADGET/idProduct"
        mkdir -p "$GADGET/functions/rndis.gs0"
        echo 1 > "$GADGET/functions/rndis.gs0/wceis" 2>/dev/null || true
        echo "02:11:22:33:44:55" > "$GADGET/functions/rndis.gs0/dev_addr"
        echo "02:11:22:33:44:56" > "$GADGET/functions/rndis.gs0/host_addr"
        echo "RNDIS" > "$GADGET/configs/c.1/strings/0x409/configuration"
        ln -sf "$GADGET/functions/rndis.gs0" "$GADGET/configs/c.1/f1"
        ;;
    mtp_adb)
        echo "0x4ee3" > "$GADGET/idProduct"
        mkdir -p "$GADGET/functions/mtp.gs0"
        mkdir -p "$GADGET/functions/ffs.adb"
        echo "MTP+ADB" > "$GADGET/configs/c.1/strings/0x409/configuration"
        ln -sf "$GADGET/functions/mtp.gs0" "$GADGET/configs/c.1/f1"
        ln -sf "$GADGET/functions/ffs.adb" "$GADGET/configs/c.1/f2"
        ;;
    rndis_adb)
        echo "0x4ee4" > "$GADGET/idProduct"
        mkdir -p "$GADGET/functions/rndis.gs0"
        echo 1 > "$GADGET/functions/rndis.gs0/wceis" 2>/dev/null || true
        echo "02:11:22:33:44:55" > "$GADGET/functions/rndis.gs0/dev_addr"
        echo "02:11:22:33:44:56" > "$GADGET/functions/rndis.gs0/host_addr"
        mkdir -p "$GADGET/functions/ffs.adb"
        echo "RNDIS+ADB" > "$GADGET/configs/c.1/strings/0x409/configuration"
        ln -sf "$GADGET/functions/rndis.gs0" "$GADGET/configs/c.1/f1"
        ln -sf "$GADGET/functions/ffs.adb" "$GADGET/configs/c.1/f2"
        ;;
    adb)
        echo "0x4ee0" > "$GADGET/idProduct"
        mkdir -p "$GADGET/functions/ffs.adb"
        echo "ADB" > "$GADGET/configs/c.1/strings/0x409/configuration"
        ln -sf "$GADGET/functions/ffs.adb" "$GADGET/configs/c.1/f1"
        ;;
    *)
        echo "Unknown mode: $MODE"
        exit 1
        ;;
esac

# Enable gadget
if ! echo "$UDC" > "$GADGET/UDC" 2>/tmp/pipa-usb-udc.err; then
    # #region agent log
    echo "DBG54b041 U-B usb-gadget UDC bind FAILED mode=$MODE udc=$UDC err=$(cat /tmp/pipa-usb-udc.err 2>/dev/null)" > /dev/kmsg
    # #endregion
    echo "UDC bind failed: $UDC" >&2
    cat /tmp/pipa-usb-udc.err >&2 || true
    exit 1
fi
# #region agent log
echo "DBG54b041 U-B usb-gadget UDC bound mode=$MODE udc=$UDC live=$(cat "$GADGET/UDC")" > /dev/kmsg
# #endregion
echo "USB gadget enabled: $MODE (UDC: $UDC)"

# Configure USB networking for RNDIS modes
case "$MODE" in
    rndis|rndis_adb)
        # Wait for usb0 to appear
        for i in $(seq 1 20); do
            [ -d /sys/class/net/usb0 ] && break
            sleep 0.1
        done

        if [ -d /sys/class/net/usb0 ]; then
            ip link set usb0 up
            ip addr flush dev usb0 2>/dev/null || true
            ip addr add 10.15.19.82/24 dev usb0

            # If dnsmasq is available, start a DHCP server for the host
            # This is the standard Droidian USB networking approach.
            # The host gets an IP like 10.15.19.xxx and SSH is:
            #   ssh droidian@10.15.19.82
            if command -v dnsmasq >/dev/null 2>&1; then
                # Kill any leftover dnsmasq on usb0 from prior runs
                pids=$(pidof dnsmasq 2>/dev/null || true)
                for p in $pids; do
                    if grep -q usb0 /proc/$p/cmdline 2>/dev/null; then
                        kill "$p" 2>/dev/null || true
                    fi
                done
                dnsmasq --interface=usb0 \
                    --dhcp-range=10.15.19.80,10.15.19.87,12h \
                    --bind-interfaces \
                    --except-interface=lo \
                    --pid-file=/run/usb-dnsmasq.pid
                echo "USB networking: 10.15.19.82/24 + dnsmasq DHCP"
            elif command -v nmcli >/dev/null 2>&1; then
                # Fallback: NM shared mode
                nmcli device set usb0 managed yes 2>/dev/null || true
                if ! nmcli connection show usb0 >/dev/null 2>&1; then
                    nmcli connection add type ethernet ifname usb0 \
                        ipv4.method shared con-name usb0 \
                        connection.autoconnect no 2>/dev/null || true
                fi
                nmcli connection up usb0 2>/dev/null || true
                echo "USB networking: NM shared mode (fallback)"
            fi
        fi
        ;;
    *)
        # Non-RNDIS modes: clean up usb0 networking
        pids=$(pidof dnsmasq 2>/dev/null || true)
        for p in $pids; do
            if grep -q usb0 /proc/$p/cmdline 2>/dev/null; then
                kill "$p" 2>/dev/null || true
            fi
        done
        rm -f /run/usb-dnsmasq.pid
        if command -v nmcli >/dev/null 2>&1; then
            if nmcli connection show usb0 >/dev/null 2>&1; then
                nmcli connection down usb0 2>/dev/null || true
                nmcli connection delete usb0 2>/dev/null || true
            fi
        fi
        ;;
esac
