#!/bin/sh
# Bring up usb0 addressing after stock mtp-configfs@rndis binds RNDIS.
# Does not configure USB gadget configfs — that is mtp-configfs's job.
set -e

MODE="${1:-}"
case "$MODE" in
    rndis|rndis_adb) ;;
    *) exit 0 ;;
esac

for i in $(seq 1 30); do
    [ -d /sys/class/net/usb0 ] && break
    sleep 0.1
done

if [ ! -d /sys/class/net/usb0 ]; then
    echo "droidian-usb-rndis-net: usb0 not present" >&2
    exit 0
fi

ip link set usb0 up
ip addr flush dev usb0 2>/dev/null || true
ip addr add 10.15.19.82/24 dev usb0

if command -v dnsmasq >/dev/null 2>&1; then
    pids=$(pidof dnsmasq 2>/dev/null || true)
    for p in $pids; do
        if grep -q usb0 /proc/$p/cmdline 2>/dev/null; then
            kill "$p" 2>/dev/null || true
        fi
    done
    dnsmasq --interface=usb0 \
        --dhcp-range=10.15.19.80,10.15.19.87,12h \
        --bind-interfaces \
        --except-interface=lo \
        --pid-file=/run/usb-dnsmasq.pid
    echo "droidian-usb-rndis-net: 10.15.19.82/24 + dnsmasq"
fi

exit 0
